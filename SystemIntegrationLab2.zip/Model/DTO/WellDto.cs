namespace Model
{
    using System;

    public partial class WellDto
    {
        public Guid ID { get; set; }
        public string Number { get; set; }
    }
}
