namespace Model
{
    using System;

    public partial class DepositDto
    {
        public Guid ID { get; set; }
        public string Name { get; set; }
    }
}
